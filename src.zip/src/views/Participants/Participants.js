import React, { Component, lazy, Suspense } from "react";
import { Bar, Line } from "react-chartjs-2";
import {
  Badge,
  Button,
  ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  CardTitle,
  Col,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Progress,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
  Table
} from "reactstrap";
import { Redirect } from "react-router-dom";

import { CustomTooltips } from "@coreui/coreui-plugin-chartjs-custom-tooltips";
import { getStyle, hexToRgba } from "@coreui/coreui/dist/js/coreui-utilities";

const Widget03 = lazy(() => import("../../views/Widgets/Widget03"));

const brandPrimary = getStyle("--primary");
const brandSuccess = getStyle("--success");
const brandInfo = getStyle("--info");
const brandWarning = getStyle("--warning");
const brandDanger = getStyle("--danger");
const padding = {
  padding: "5px"
};

class Participants extends Component {
  constructor(props) {
    super(props);
    var admin = false;
    if(localStorage.getItem('USER').toUpperCase() === 'ANTHEM') {
      admin = true;
    }
    this.state = {
      data: [],
      toParticipant: false,
      toUpdate: false,
      isUserAdmin: admin,
      orgId: "",
      orgName: ""
    };
    
    this.fetchApi();
  }

  myChangeHandler = (name, event) => {
    this.setState({ ...this.state, [name]: event.target.value });
  };

  loadParticipants() {
    this.setState({
      toParticipant: false
    });
    this.fetchApi();
  }

  saveParticipant() {
    if (this.state.toUpdate) {
      this.callUpdateParticipantApi();
    } else {
      this.callNewParticipantApi();
    }

    //this.loadCheck();
  }

  callNewParticipantApi() {
    fetch("http://localhost:3000/api/Participants", {
      method: "POST",
      body: JSON.stringify({
        $class: "org.recon.biznet.Participants",
        orgId: this.state.orgId,
        orgName: this.state.orgName
      }),

      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(res => {
        console.log("success " + JSON.stringify(res));
        alert("Added successfully");
        this.loadParticipants();
        return res;
      })
      .catch(err => {
        err;
        console.log("error");
        console.log("failure " + err);
      });
  }

  updateParticipant(participantObj) {
    this.setState({
      toParticipant: true,
      toUpdate: true,
      orgId: participantObj.orgId,
      orgName: participantObj.orgName
    });
  }

  callUpdateParticipantApi() {
    fetch("http://localhost:3000/api/Participants" + this.state.orgId, {
      method: "PUT",
      body: JSON.stringify({
        $class: "org.recon.biznet.Participants",
        orgId: this.state.orgId,
        orgName: this.state.orgName
      }),
      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(res => {
        console.log("success " + JSON.stringify(res));
        alert("Updated successfully");
        this.loadParticipants();
        return res;
      })
      .catch(err => {
        err;
        console.log("error");
        console.log("failure " + err);
      });
  }

  fetchApi() {
    fetch("http://localhost:3000/api/Participants")
      .then(result => {
        return result.json();
      })
      .then(jsonResult => {
        this.setState({ data: jsonResult });
      });
  }

  addParticipant() {
    this.setState({
      toParticipant: true,
      toUpdate: false,
      type: 'new',
      orgId: '',
      orgName: ''
    });
  }

  loading = () => (
    <div className="animated fadeIn pt-1 text-center">Loading...</div>
  );

  render() {
    if (!this.state.isUserAdmin) {
      return <Redirect to="/admin/check" />;
    }

    if (this.state.toParticipant === true) {
      return (
        <div>
          <Button
            type="button"
            size="sm"
            color="primary"
            onClick={() => this.loadParticipants()}
          >
            <i className="fa fa-arrow-circle-o-left"></i> Go Back
          </Button>
          <div style={padding}></div>
          <Card>
            <CardHeader>Participants Details</CardHeader>
            <CardBody>
              <Form action="" method="post" className="form-horizontal">
                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="checkNum">Org ID</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="orgId"
                      name="orgId"
                      placeholder="Enter ID"
                      autoComplete="orgId"
                      value={this.state.orgId || ""}
                      onChange={e => this.myChangeHandler("orgId", e)}
                      readOnly={this.state.toUpdate ? 'readOnly' : undefined}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="checkAmt">Org Name</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="orgName"
                      name="orgName"
                      placeholder="Enter Name"
                      autoComplete="checkNum"
                      value={this.state.orgName || ""}
                      onChange={e => this.myChangeHandler("orgName", e)}
                    />
                  </Col>
                </FormGroup>
              </Form>
            </CardBody>
            <CardFooter>
              <Button
                type="submit"
                size="sm"
                color="primary"
                onClick={() => this.saveParticipant()}
              >
                <i className="fa fa-dot-circle-o"></i> Save
              </Button>
              <Button type="reset" size="sm" color="danger">
                <i className="fa fa-ban"></i> Reset
              </Button>
            </CardFooter>
          </Card>
        </div>
      );
    }

    const table = this.state.data.map((link, index) => (
      <tr key={index}>
        <td className="text-center">
          {index+1}
        </td>
        <td className="text-center">{link.orgId}</td>
        <td className="text-center">{link.orgName}</td>
        {/*<td className="text-center">{link.Org}</td> */}
        <td>
          <div className="row">
            <div className="col-sm-4"></div>
            <div className="col-sm-4">
              <i
                className="cui-note icons font-2xl d-block"
                onClick={() =>
                  this.updateParticipant(link)
                }
              ></i>
            </div>
          </div>
        </td>
      </tr>
    ));

    return (
      <div className="animated fadeIn">
        <Row>
          <Col>
            <Card>
              <CardHeader>Participants
              <Button
                type="submit"
                size="sm"
                color="primary"
                className="pull-right"
                onClick={() => this.addParticipant()}
                disabled={this.state.isUserAdmin ? undefined : 'disabled'}
              >
                <i className="fa fa-plus"></i> Add Participants
              </Button>
              </CardHeader>
              <CardBody>
                <Table
                  hover
                  responsive
                  className="table-outline mb-0 d-none d-sm-table"
                >
                  <thead className="thead-light">
                    <tr>
                      <th className="text-center">
                        <i className="icon-people"></i>
                      </th>
                      <th className="text-center">Organization ID</th>
                      <th className="text-center">Organization Name</th>
                      {/*<th> className="text-center"Organization</th> */}
                      <th className="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>{table}</tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Participants;
