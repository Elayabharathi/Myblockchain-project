import React, { Component, lazy, Suspense } from "react";
import { Bar, Line } from "react-chartjs-2";
import {
  Badge,
  Button,
  ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  CardTitle,
  Col,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Progress,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
  Table
} from "reactstrap";
import { Redirect } from "react-router-dom";

import { CustomTooltips } from "@coreui/coreui-plugin-chartjs-custom-tooltips";
import { getStyle, hexToRgba } from "@coreui/coreui/dist/js/coreui-utilities";

const Widget03 = lazy(() => import("../../views/Widgets/Widget03"));

const brandPrimary = getStyle("--primary");
const brandSuccess = getStyle("--success");
const brandInfo = getStyle("--info");
const brandWarning = getStyle("--warning");
const brandDanger = getStyle("--danger");
const padding = {
  padding: "5px"
};

class Check extends Component {
  constructor(props) {
    super(props);
    var admin = false;
    var userName = localStorage.getItem('USER').toUpperCase();
    if(userName === 'Payer') {
      admin = true;
    }
    this.state = {
      data: [],
      userName: userName,
      isUserAdmin: admin,
      toAdminPage: false,
      toCheck: false,
      isReadonly: false,
      isReissueUpdate: false,
      type: "",
      checkNum: "",
      checkAmt: "",
      status: "",
      reissueStatus: "",
      reissueCheckNum: "",
      reissueCheckAmt: "",
      payeeId: "",
      payeeName: "",
      Org: ""
    };
    
    this.fetchApi();
  }

  myChangeHandler = (name, event) => {
    this.setState({ ...this.state, [name]: event.target.value });
  };

  loadCheck() {
    this.setState({
      toCheck: false
    });
    this.fetchApi();
  }

  saveCheck() {
    if (this.state.type === "checkInsert") {
      this.callInsertCheckApi();
    } else if (this.state.type === "checkUpdate") {
      this.callUpdateCheckApi();
    } else if (this.state.type === "payerReissueUpdate") {
      this.callPayerReissueUpdateApi();
    }

    //this.loadCheck();
  }

  callInsertCheckApi() {
    fetch("http://localhost:3000/api/Check/", {
      method: "POST",
      body: JSON.stringify({
        $class: "org.recon.biznet.Check",
        checkNumber: this.state.checkNum,
        checkAmt: this.state.checkAmt,
        checkStatus: this.state.status,
        reissCheckNumber: "0",
        reissCheckAmt: "0",
        payeeID: this.state.payeeId,
        payeeName: this.state.payeeName,
        Org: this.state.userName
      }),

      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(res => {
        console.log("success " + JSON.stringify(res));
        alert("Inserted successfully");
        this.loadCheck();
        return res;
      })
      .catch(err => {
        err;
        console.log("error");
        console.log("failure " + err);
      });
  }

  callUpdateCheckApi() {
    fetch("http://localhost:3000/api/Update", {
      method: "POST",
      body: JSON.stringify({
        $class: "org.recon.biznet.Update",
        check: "org.recon.biznet.Check#" + this.state.checkNum,
        newStatus: this.state.status,
        newOrg: this.state.userName
      }),

      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(res => {
        console.log("success " + JSON.stringify(res));
        alert("Updated successfully");
        this.loadCheck();
        return res;
      })
      .catch(err => {
        err;
        console.log("error");
        console.log("failure " + err);
      });
  }

  callPayerReissueUpdateApi() {
    var date = new Date();
    var yr = date.getFullYear();
    var month = (Number(date.getMonth()) + 1).toString().padStart(2, "0");
    var day = date.getDate();
    var time = date.toLocaleTimeString() + "." + date.getMilliseconds();
    var timestamp = yr + "-" + month + "-" + day + "T" + time + "Z";
    fetch("http://localhost:3000/api/PayerReissueUpdate", {
      method: "POST",
      body: JSON.stringify({
        $class: "org.recon.biznet.PayerReissueUpdate",
        check: "org.recon.biznet.Check#" + this.state.checkNum,
        reissueStatus: this.state.reissueStatus,
        reissCheckNumber: this.state.reissueCheckNum,
        reissCheckAmt: this.state.reissueCheckAmt,
        payer: this.state.userName
      }),

      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(res => {
        console.log("success " + JSON.stringify(res));
        alert("Updated successfully");
        this.loadCheck();
        return res;
      })
      .catch(err => {
        err;
        console.log("error");
        console.log("failure " + err);
      });
  }

  fetchApi() {
    fetch("http://localhost:3000/api/Check")
      .then(result => {
        return result.json();
      })
      .then(jsonResult => {
        this.setState({ data: jsonResult });
      });
  }

  loadCheckDetails(checkObj, type) {
    var check = checkObj;
    var org = check.Org.split("#");
    this.setState({
      toCheck: true,
      type: type,
      checkNum: check.checkNumber,
      checkAmt: check.checkAmt,
      status: check.checkStatus,
      reissueStatus: check.reissueStatus,
      reissueCheckNum: check.reissCheckNumber,
      reissueCheckAmt: check.reissCheckAmt,
      payeeId: check.payeeID,
      payeeName: check.payeeName,
      Org: org[1]
    });
    if (type === "checkUpdate") {
      this.setState({
        isReadonly: true,
        isReissueUpdate: false
      });
    } else if (type === "payerReissueUpdate") {
      this.setState({
        isReadonly: true,
        isReissueUpdate: true
      });
    } else if (type === "checkView") {
      this.setState({
        isReadonly: true,
        isReissueUpdate: false
      });
    }
  }

  addCheck() {
    this.setState({
      toCheck: true,
      isReadonly: false,
      isReissueUpdate: false,
      type: "checkInsert",
      checkNum: "",
      checkAmt: "",
      status: "",
      reissueStatus: "",
      reissueCheckNum: "",
      reissueCheckAmt: "",
      payeeId: "",
      payeeName: "",
    });
  }

  loading = () => (
    <div className="animated fadeIn pt-1 text-center">Loading...</div>
  );

  render() {
    if (this.state.toAdminPage === true) {
      return <Redirect to="/admin/check" />;
    }

    if (this.state.toCheck === true) {
      return (
        <div>
          <Button
            type="button"
            size="sm"
            color="primary"
            onClick={() => this.loadCheck()}
          >
            <i className="fa fa-arrow-circle-o-left"></i> Go Back
          </Button>
          <div style={padding}></div>
          <Card>
            <CardHeader>Check Details</CardHeader>
            <CardBody>
              <Form action="" method="post" className="form-horizontal">
                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="checkNum">Check Number</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="checkNum"
                      name="checkNum"
                      placeholder="Enter Check Number"
                      autoComplete="checkNum"
                      value={this.state.checkNum || ""}
                      onChange={e => this.myChangeHandler("checkNum", e)}
                      readOnly={this.state.isReadonly ? 'readOnly' : undefined}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="checkAmt">Check Amount</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="checkAmt"
                      name="checkAmt"
                      placeholder="Enter Check Amount"
                      autoComplete="checkNum"
                      value={this.state.checkAmt || ""}
                      onChange={e => this.myChangeHandler("checkAmt", e)}
                      readOnly={this.state.isReadonly ? 'readOnly' : undefined}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="status">Check Status</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="status"
                      name="status"
                      placeholder="Enter Check Status"
                      autoComplete="status"
                      value={this.state.status || ""}
                      onChange={e => this.myChangeHandler("status", e)}
                      readOnly={(this.state.isReissueUpdate || this.state.type === 'checkView') ? 'readOnly' : undefined}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="reissueCheckNum">
                      Re-issue Check Number
                    </Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="reissueCheckNum"
                      name="reissueCheckNum"
                      placeholder="Enter Re-issue Check Number"
                      autoComplete="reissueCheckNum"
                      value={this.state.reissueCheckNum || ""}
                      onChange={e => this.myChangeHandler("reissueCheckNum", e)}
                      readOnly={this.state.isReissueUpdate ? undefined : 'readOnly'}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="reissueCheckAmt">
                      Re-issue Check Amount
                    </Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="reissueCheckAmt"
                      name="reissueCheckAmt"
                      placeholder="Enter Re-issue Check Amount"
                      autoComplete="reissueCheckAmt"
                      value={this.state.reissueCheckAmt || ""}
                      onChange={e => this.myChangeHandler("reissueCheckAmt", e)}
                      readOnly={this.state.isReissueUpdate ? undefined : 'readOnly'}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="reissueStatus">Re-issue Check Status</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="reissueStatus"
                      name="reissueStatus"
                      placeholder="Enter Re-issue Check Status"
                      autoComplete="reissueStatus"
                      value={this.state.reissueStatus || ""}
                      onChange={e => this.myChangeHandler("reissueStatus", e)}
                      readOnly={this.state.isReissueUpdate ? undefined : 'readOnly'}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="payeeId">Payee ID</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="payeeId"
                      name="payeeId"
                      placeholder="Enter Payee ID"
                      autoComplete="payeeId"
                      value={this.state.payeeId || ""}
                      onChange={e => this.myChangeHandler("payeeId", e)}
                      readOnly={this.state.isReadonly ? 'readOnly' : undefined}
                    />
                  </Col>
                </FormGroup>

                <FormGroup row>
                  <Col md="3">
                    <Label htmlFor="payeeName">Payee Name</Label>
                  </Col>
                  <Col xs="12" md="5">
                    <Input
                      type="text"
                      id="payeeName"
                      name="payeeName"
                      placeholder="Enter Payee Name"
                      autoComplete="payeeName"
                      value={this.state.payeeName || ""}
                      onChange={e => this.myChangeHandler("payeeName", e)}
                      readOnly={this.state.isReadonly ? 'readOnly' : undefined}
                    />
                  </Col>
                </FormGroup>
              </Form>
            </CardBody>
            <CardFooter>
              <Button
                type="submit"
                size="sm"
                color="primary"
                onClick={() => this.saveCheck()}
                disabled={this.state.type !== 'checkView' ? undefined : 'disabled'}
              >
                <i className="fa fa-dot-circle-o"></i> Save
              </Button>
              <Button type="reset" size="sm" color="danger">
                <i className="fa fa-ban"></i> Reset
              </Button>
            </CardFooter>
          </Card>
        </div>
      );
    }
/**
"transactionId": "org.recon.biznet.transactionId#12324",
  "timestamp": "2020-03-28T11:14:52.273Z"
 */
    const table = this.state.data
    .filter(check => {
      if(this.state.isUserAdmin) {
        return check;
      } else if(this.state.userName === check.payeeID) {
        return check;
      } else if(this.state.userName === 'BOA' && check.checkNumber.substring(0,4) === '0001') {
        return check;
      } else if(this.state.userName === 'PNC' && check.checkNumber.substring(0,4) === '0002') {
        return check;
      } else if(this.state.userName === 'CHASE' && check.checkNumber.substring(0,4) === '0003') {
        return check;
      }
    })
    .map((link,index) => (
      <tr key={index}>
        <td className="text-center">{index + 1}</td>
        {/*<td className="text-center">
          <div className="avatar">
            <img
              src={"assets/img/avatars/6.jpg"}
              className="img-avatar"
              alt="admin@bootstrapmaster.com"
            />
            <span className="avatar-status badge-danger"></span>
          </div>
        </td>*/}
        <td className="text-center">{link.checkNumber}</td>
        <td className="text-center">{link.checkAmt}</td>
        <td className="text-center">{link.checkStatus}</td>
        <td className="text-center">{link.payeeID}</td>
        <td className="text-center">{link.payeeName}</td>
        {/*<td className="text-center">{link.Org}</td> */}
        <td>
          <div className="row">
          <div className="col-sm-2"></div>
          <div className="col-sm-3">
              <i
                className="cui-info icons font-2xl d-block"
                onClick={() => this.loadCheckDetails(link, "checkView")}
              ></i>
            </div>
            <div className="col-sm-3">
              <i
                className="cui-note icons font-2xl d-block"
                onClick={() => this.loadCheckDetails(link, "checkUpdate")}
              ></i>
            </div>
            <div className="col-sm-3" style={{display: (link.checkStatus.toLowerCase() === 'reissue request' && this.state.isUserAdmin) ? undefined :'none'}}>
              <i
                className="cui-task icons font-2xl d-block"
                onClick={() =>
                  this.loadCheckDetails(link, "payerReissueUpdate")
                }
              ></i>
            </div>
          </div>
        </td>
      </tr>
    ));

    return (
      <div className="animated fadeIn">
        <Row>
          <Col>
            <Card>
              <CardHeader>List of Payments
              <Button
                type="submit"
                size="sm"
                color="primary"
                className="pull-right"
                onClick={() => this.addCheck()}
                disabled={this.state.isUserAdmin ? undefined : 'disabled'}
              >
                <i className="fa fa-plus"></i> Add Check
              </Button>
              </CardHeader>
              <CardBody>
                <Table
                  hover
                  responsive
                  className="table-outline mb-0 d-none d-sm-table"
                >
                  <thead className="thead-light">
                    <tr>
                      <th className="text-center">
                        #
                      </th>
                      <th className="text-center">Check Number</th>
                      <th className="text-center">Check Amt</th>
                      <th className="text-center">Status</th>
                      <th className="text-center">Payee ID</th>
                      <th className="text-center">Payee Name</th>
                      {/*<th> className="text-center"Organization</th> */}
                      <th className="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>{table}</tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Check;
